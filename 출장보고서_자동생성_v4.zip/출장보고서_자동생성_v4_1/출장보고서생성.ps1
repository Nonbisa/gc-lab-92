﻿# Windows PowerShell 5.1 / 한글 COM Automation
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
# Keep mutex names short and deterministic, even for long directory names.
$sha = [Security.Cryptography.SHA256]::Create()
try { $mutexName = 'Local\TripReport_' + ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($PSScriptRoot.ToLowerInvariant())))).Replace('-','') }
finally { $sha.Dispose() }
$created = $false
$RunMutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$created)
if (-not $created) {
    Write-Host '이 폴더의 프로그램이 이미 실행 중입니다. 기존 작업을 마친 뒤 실행하세요.'
    $RunMutex.Dispose()
    exit 2
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$Base = $PSScriptRoot
$OutDir = Join-Path $Base '보고서 결과'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$Stamp = (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0,6)
$TempDir = $null
$Hwp = $null
$Succeeded = 0
$Failed = 0
$Warnings = 0
$Stage = '초기화'
function Write-Log([string]$Text) {
    $line = ('[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $Text)
    Write-Host $line
}
function Read-ZipText($Zip, [string]$Path) {
    $entry = $Zip.GetEntry($Path)
    if ($null -eq $entry) { throw "엑셀 내부 항목이 없습니다: $Path" }
    $reader = New-Object System.IO.StreamReader($entry.Open())
    try { return $reader.ReadToEnd() } finally { $reader.Dispose() }
}
function Read-ZipXml($Zip, [string]$Path) {
    $doc = New-Object System.Xml.XmlDocument
    $doc.XmlResolver = $null
    $doc.LoadXml((Read-ZipText $Zip $Path))
    return ,$doc
}
function Get-ColNumber([string]$Address) {
    $n=0
    foreach ($ch in ([regex]::Match($Address,'^[A-Z]+').Value.ToCharArray())) {
        $n = $n * 26 + [int]$ch - [int][char]'A' + 1
    }
    return $n
}
function Get-CellValue($Row, [int]$Col) {
    if ($Row.ContainsKey($Col)) { return ([string]$Row[$Col]).Trim() }
    return ''
}
function Parse-Date([string]$Value) {
    $s=$Value.Trim()
    $number=0.0
    if ([double]::TryParse($s,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$number)) {
        if ($number -lt 1 -or $number -gt 2958465) { throw "엑셀 날짜 값이 올바르지 않습니다: $s" }
        return [datetime]::FromOADate($number)
    }
    $result=[datetime]::MinValue
    $formats=[string[]]@('yyyy-MM-dd HH:mm','yyyy-MM-dd HH:mm:ss','yyyy/MM/dd HH:mm','yyyy.MM.dd HH:mm','yyyy-MM-ddTHH:mm:ss','yyyy-M-d H:mm','yyyy-M-d H:mm:ss')
    if ([datetime]::TryParseExact($s,$formats,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$result)) { return $result }
    throw "날짜와 시간을 읽을 수 없습니다: '$s' (예: 2026-09-29 10:30)"
}
function Format-TripDate($Start,$End) {
    $days=@('일','월','화','수','목','금','토')
    $first='{0}({1}) {2}' -f $Start.ToString('yyyy-MM-dd'),$days[[int]$Start.DayOfWeek],$Start.ToString('HH:mm')
    if ($Start.Date -eq $End.Date) { return $first + '~' + $End.ToString('HH:mm') }
    return $first + '~' + ('{0}({1}) {2}' -f $End.ToString('yyyy-MM-dd'),$days[[int]$End.DayOfWeek],$End.ToString('HH:mm'))
}
function Read-Trips([string]$Path,$Config) {
    $zip=[IO.Compression.ZipFile]::OpenRead($Path)
    try {
        $shared=New-Object 'System.Collections.Generic.List[string]'
        if ($null -ne $zip.GetEntry('xl/sharedStrings.xml')) {
            $sx=Read-ZipXml $zip 'xl/sharedStrings.xml'
            foreach ($si in $sx.SelectNodes('/*[local-name()="sst"]/*[local-name()="si"]')) {
                $texts=@($si.SelectNodes('.//*[local-name()="t"]') | ForEach-Object { $_.InnerText })
                $shared.Add(($texts -join ''))
            }
        }
        $wb=Read-ZipXml $zip 'xl/workbook.xml'
        $date1904=$wb.SelectSingleNode('/*[local-name()="workbook"]/*[local-name()="workbookPr"]')
        $use1904=($null -ne $date1904 -and $date1904.GetAttribute('date1904') -in @('1','true'))
        $rels=Read-ZipXml $zip 'xl/_rels/workbook.xml.rels'
        $relmap=@{}
        foreach ($rel in $rels.DocumentElement.ChildNodes) {
            if ($rel.GetAttribute('TargetMode') -ne 'External') { $relmap[$rel.GetAttribute('Id')]=$rel.GetAttribute('Target') }
        }
        $excludedKind=0
        $records=New-Object 'System.Collections.Generic.List[object]'
        foreach ($sheet in $wb.SelectNodes('/*[local-name()="workbook"]/*[local-name()="sheets"]/*[local-name()="sheet"]')) {
            $rid=$sheet.GetAttribute('id','http://schemas.openxmlformats.org/officeDocument/2006/relationships')
            $target=$relmap[$rid]
            if (-not $target) { throw '시트 경로를 찾을 수 없습니다.' }
            if ($target.StartsWith('/')) { $sheetPath=$target.TrimStart('/') }
            else { $sheetPath=([uri]::new([uri]'http://local/xl/workbook.xml',[string]$target)).AbsolutePath.TrimStart('/') }
            if (-not $sheetPath.EndsWith('.xml')) { continue }
            $sx=Read-ZipXml $zip $sheetPath
            $columns=@{}
            $headerFound=$false
            foreach ($row in $sx.SelectNodes('/*[local-name()="worksheet"]/*[local-name()="sheetData"]/*[local-name()="row"]')) {
                $values=@{}
                foreach ($cell in $row.SelectNodes('./*[local-name()="c"]')) {
                    $col=Get-ColNumber $cell.GetAttribute('r')
                    $v=$cell.SelectSingleNode('./*[local-name()="v"]')
                    $value=''
                    switch ($cell.GetAttribute('t')) {
                        's' { if ($null -ne $v) { $value=$shared[[int]$v.InnerText] } }
                        'inlineStr' { $value=(@($cell.SelectNodes('./*[local-name()="is"]//*[local-name()="t"]') | ForEach-Object {$_.InnerText}) -join '') }
                        default { if ($null -ne $v) { $value=$v.InnerText } }
                    }
                    $values[$col]=$value
                }
                $header=@{}
                foreach ($key in $values.Keys) { $header[([string]$values[$key]).Trim()]=$key }
                if ($header.ContainsKey('순번') -and $header.ContainsKey('출발일자') -and $header.ContainsKey('출장자')) {
                    foreach ($name in @('순번','출발일자','도착일자','출장지','출장목적','출장자')) {
                        if (-not $header.ContainsKey($name)) { throw "시트 '$($sheet.GetAttribute('name'))': '$name' 열이 없습니다." }
                        $columns[$name]=$header[$name]
                    }
                    if ($header.ContainsKey('내역종류')) { $columns['내역종류']=$header['내역종류'] }
                    else { $columns['내역종류']=[int]$Config.status_column }
                    $headerFound=$true
                    continue
                }
                if (-not $headerFound) { continue }
                $kind=Get-CellValue $values $columns['내역종류']
                if ($kind -cne '확인') { $excludedKind++; continue }
                $seq=Get-CellValue $values $columns['순번']
                $issues=New-Object 'System.Collections.Generic.List[string]'
                $sv=Get-CellValue $values $columns['출발일자']
                $ev=Get-CellValue $values $columns['도착일자']
                $person=Get-CellValue $values $columns['출장자']
                $place=Get-CellValue $values $columns['출장지']
                $purpose=Get-CellValue $values $columns['출장목적']
                $start=$null; $end=$null
                $seqNumber=[long]0
                if (-not [long]::TryParse($seq,[ref]$seqNumber) -or $seqNumber -lt 0) {
                    $issues.Add('순번이 비어 있거나 올바른 정수가 아닙니다.')
                }
                foreach ($field in @('출발일자','도착일자','출장자','출장지','출장목적')) {
                    $raw=Get-CellValue $values $columns[$field]
                    if ($raw -match '^#(NULL!|DIV/0!|VALUE!|REF!|NAME\?|NUM!|N/A|SPILL!|CALC!|GETTING_DATA)$') {
                        $issues.Add("${field}에 엑셀 오류 값이 있습니다: $raw")
                    }
                }
                try {
                    $start=Parse-Date $sv
                    $dummy=0.0
                    if ($use1904 -and [double]::TryParse($sv,[ref]$dummy)) { $start=$start.AddDays(1462) }
                } catch { $issues.Add('출발일자 오류: '+$_.Exception.Message) }
                try {
                    $end=Parse-Date $ev
                    $dummy=0.0
                    if ($use1904 -and [double]::TryParse($ev,[ref]$dummy)) { $end=$end.AddDays(1462) }
                } catch { $issues.Add('도착일자 오류: '+$_.Exception.Message) }
                if ($null -ne $start -and $null -ne $end) {
                    $date=Format-TripDate $start $end
                    if ($end -lt $start) { $issues.Add('도착 시각이 출발 시각보다 빠릅니다.') }
                } else {
                    $startRaw=$sv; $endRaw=$ev
                    if (-not $startRaw) { $startRaw='[출발일자 누락]' }
                    if (-not $endRaw) { $endRaw='[도착일자 누락]' }
                    $date=$startRaw+' ~ '+$endRaw
                }
                if (-not $person) { $issues.Add('출장자가 비어 있습니다.'); $person='[출장자 누락]' }
                if (-not $place) { $issues.Add('출장지가 비어 있습니다.'); $place='[출장지 누락]' }
                if (-not $purpose) { $issues.Add('출장목적이 비어 있습니다.'); $purpose='[출장목적 누락]' }
                $position=''
                if ($script:PositionIssues.ContainsKey($person)) {
                    $issues.Add([string]$script:PositionIssues[$person])
                } elseif (-not $script:PositionMap.ContainsKey($person)) {
                    $issues.Add("직위목록.csv에 '$person'의 직위가 등록되어 있지 않습니다.")
                } else {
                    $position=[string]$script:PositionMap[$person]
                    if (-not $position.Trim()) { $issues.Add("'$person'의 직위가 비어 있습니다.") }
                }
                if (-not $position.Trim()) { $position='[직위 확인 필요]' }
                $text=('1. 일시: '+$date)+"`r`n"+('2. 대상: '+$position+' '+$person)+"`r`n"+('3. 장소: '+$place)+"`r`n"+('4. 목적: '+$purpose)
                if ($issues.Count -gt 0) {
                    $source="시트 $($sheet.GetAttribute('name')), 행 $($row.GetAttribute('r')), 순번 $seq"
                    $text+="`r`n"+'[오류 확인 필요] '+$source+"`r`n"+($issues -join "`r`n")
                    Write-Log ('내역 오류: '+$source+' / '+($issues -join ' / '))
                }
                $records.Add([pscustomobject]@{
                    시트=$sheet.GetAttribute('name'); 엑셀행=$row.GetAttribute('r'); 순번=$seq; 내역종류=$kind
                    일시=$date; 대상=($position+' '+$person); 장소=$place; 목적=$purpose; Text=$text
                    StartDateTime=$start; SourceOrder=$records.Count
                    HasError=($issues.Count -gt 0); ErrorMessages=$issues.ToArray()
                })
            }
        }
        Write-Log "확인 외 행 제외: $excludedKind 건 / 확인 내역: $($records.Count) 건"
        return $records.ToArray()
    } finally { $zip.Dispose() }
}

function Read-PositionMap([string]$Path) {
    $script:PositionIssues=@{}
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Write-Log '직위목록.csv가 없어 모든 확인 내역에 직위 확인 필요 표시를 합니다.'
        return @{}
    }
    $bytes=[IO.File]::ReadAllBytes($Path)
    try {
        $decoder=New-Object System.Text.UTF8Encoding($false,$true)
        $content=$decoder.GetString($bytes).TrimStart([char]0xFEFF)
    } catch {
        $content=[Text.Encoding]::GetEncoding(949).GetString($bytes)
    }
    $rows=@($content | ConvertFrom-Csv)
    if ($rows.Count -eq 0) { Write-Log '직위 목록에 사람이 없습니다. 직위 누락으로 표시합니다.'; return @{} }
    if ($null -eq $rows[0].PSObject.Properties['성명'] -or $null -eq $rows[0].PSObject.Properties['직위']) {
        throw '직위목록.csv의 첫 줄은 성명,직위여야 합니다.'
    }
    $map=@{}
    foreach ($row in $rows) {
        $person=([string]$row.성명).Trim()
        $position=([string]$row.직위).Trim()
        if (-not $person -and -not $position) { continue }
        if (-not $person) { Write-Log '직위목록.csv에서 이름이 없는 행은 연결할 수 없어 건너뜁니다.'; continue }
        if ($map.ContainsKey($person)) {
            $script:PositionIssues[$person]="직위목록.csv에 '$person'이 중복되어 직위를 확정할 수 없습니다."
            $map[$person]=''
            continue
        }
        $map[$person]=$position
    }
    if ($map.Count -eq 0) { Write-Log '사용할 수 있는 직위 목록이 없어 직위 누락으로 표시합니다.' }
    return $map
}
function Escape-Html([string]$Value) {
    return [Net.WebUtility]::HtmlEncode($Value).Replace("`r`n",'<br>').Replace("`r",'<br>').Replace("`n",'<br>')
}
function Write-TableHtml($Trips,$Config,[string]$Path) {
    $size=([double]$Config.font_size).ToString([Globalization.CultureInfo]::InvariantCulture)
    $sb=New-Object Text.StringBuilder
    [void]$sb.AppendLine('<!DOCTYPE html><html><head><meta charset="utf-8"><meta http-equiv="Content-Type" content="text/html; charset=utf-8">')
    [void]$sb.AppendLine('<style>@page {size:A4; margin:20mm;} body {margin:0; color:#000; background:#fff; font-family:"맑은 고딕",sans-serif;} table {width:100%;border-collapse:collapse;table-layout:fixed;} td {border:1px solid #000;padding:10px;vertical-align:top;page-break-inside:avoid;} tr {page-break-inside:avoid;break-inside:avoid;} p {margin:0 0 4px 0;line-height:150%;}</style></head>')
    [void]$sb.AppendLine(('<body style="font-size:{0}pt"><table border="1" cellspacing="0" cellpadding="10" width="100%"><tbody>' -f $size))
    foreach ($trip in $Trips) {
        $color='#000000'
        if ($trip.HasError) { $color='#FF0000' }
        [void]$sb.AppendLine(('<tr><td style="font-size:{0}pt;color:{1}">' -f $size,$color))
        foreach ($line in ($trip.Text -split '\r?\n')) {
            [void]$sb.AppendLine(('<p style="color:{0}"><font color="{0}">{1}</font></p>' -f $color,(Escape-Html $line)))
        }
        [void]$sb.AppendLine('</td></tr>')
    }
    [void]$sb.AppendLine('</tbody></table></body></html>')
    [IO.File]::WriteAllText($Path,$sb.ToString(),(New-Object Text.UTF8Encoding($true)))
}
function Set-PageAndFont($Config) {
    $Hwp.HAction.Run('MoveDocBegin') | Out-Null
    $Hwp.HAction.GetDefault('PageSetup',$Hwp.HParameterSet.HSecDef.HSet) | Out-Null
    $pg=$Hwp.HParameterSet.HSecDef.PageDef
    $pg.PaperWidth=59528; $pg.PaperHeight=84189; $pg.Landscape=0
    $pg.LeftMargin=5669; $pg.RightMargin=5669
    $pg.TopMargin=5669; $pg.BottomMargin=5669
    $pg.HeaderLen=0; $pg.FooterLen=0; $pg.GutterLen=0
    if (-not $Hwp.HAction.Execute('PageSetup',$Hwp.HParameterSet.HSecDef.HSet)) { throw 'A4 페이지 설정에 실패했습니다.' }
    # Font family and size are provided by HTML; preserve per-cell colors.
    $Hwp.HAction.Run('MoveDocBegin') | Out-Null
}
function Set-HwpxErrorColors([string]$Path,$Trips) {
    # Modify the closed HWPX package. Only error-cell character styles are cloned.
    $errorTrips=@($Trips | Where-Object { $_.HasError })
    if ($errorTrips.Count -eq 0) { return }
    $zip=[IO.Compression.ZipFile]::Open($Path,[IO.Compression.ZipArchiveMode]::Update)
    try {
        $header=Read-ZipXml $zip 'Contents/header.xml'
        $list=$header.SelectSingleNode('//*[local-name()="charProperties"]')
        if ($null -eq $list) { throw 'HWPX 글자 속성 목록이 없어 빨간색을 적용할 수 없습니다.' }
        $styles=@{}; $nextId=0
        foreach ($style in $list.SelectNodes('./*[local-name()="charPr"]')) {
            $id=$style.GetAttribute('id'); $styles[$id]=$style
            $nextId=[Math]::Max($nextId,([int]$id+1))
        }
        $sections=New-Object 'System.Collections.Generic.List[object]'
        $cells=New-Object 'System.Collections.Generic.List[object]'
        foreach ($entry in @($zip.Entries | Where-Object {$_.FullName -match '^Contents/section\d+\.xml$'} | Sort-Object {[int]([regex]::Match($_.FullName,'section(\d+)').Groups[1].Value)})) {
            $xml=Read-ZipXml $zip $entry.FullName
            $sections.Add([pscustomobject]@{Path=$entry.FullName; Xml=$xml})
            foreach ($table in $xml.SelectNodes('//*[local-name()="tbl"]')) {
                foreach ($cell in $table.SelectNodes('./*[local-name()="tr"]/*[local-name()="tc"]')) { $cells.Add($cell) }
            }
        }
        if ($cells.Count -ne $Trips.Count) { throw '표 칸 수가 일치하지 않아 색상 적용을 중단했습니다.' }
        $clones=@{}
        for ($i=0; $i -lt $cells.Count; $i++) {
            if (-not $Trips[$i].HasError) { continue }
            $actual=(@($cells[$i].SelectNodes('.//*[local-name()="t"]') | ForEach-Object {$_.InnerText}) -join '') -replace '\s+',''
            if ($actual -cne ($Trips[$i].Text -replace '\s+','')) { throw "출력 $($i+1)번째 오류 칸의 내용이 달라 색상 적용을 중단했습니다." }
            foreach ($run in $cells[$i].SelectNodes('.//*[local-name()="run"]')) {
                $baseId=$run.GetAttribute('charPrIDRef')
                if (-not $styles.ContainsKey($baseId)) { throw "글자 속성 $baseId 를 찾을 수 없습니다." }
                if (-not $clones.ContainsKey($baseId)) {
                    $clone=$styles[$baseId].CloneNode($true)
                    $newId=[string]$nextId; $nextId++
                    $clone.SetAttribute('id',$newId); $clone.SetAttribute('textColor','#FF0000')
                    [void]$list.AppendChild($clone)
                    $clones[$baseId]=$newId
                }
                $run.SetAttribute('charPrIDRef',[string]$clones[$baseId])
            }
        }
        $styleCount=$list.SelectNodes('./*[local-name()="charPr"]').Count
        $list.SetAttribute('itemCnt',[string]$styleCount)
        $updates=@([pscustomobject]@{Path='Contents/header.xml'; Xml=$header})+@($sections.ToArray())
        foreach ($item in $updates) {
            $zip.GetEntry($item.Path).Delete()
            $newEntry=$zip.CreateEntry($item.Path)
            $stream=$newEntry.Open()
            $settings=New-Object System.Xml.XmlWriterSettings
            $settings.Encoding=New-Object System.Text.UTF8Encoding($false)
            $writer=[System.Xml.XmlWriter]::Create($stream,$settings)
            try { $item.Xml.Save($writer) } finally { $writer.Dispose(); $stream.Dispose() }
        }
    } finally { $zip.Dispose() }
}
function Test-HwpxTable([string]$Path,$Trips) {
    $zip=[IO.Compression.ZipFile]::OpenRead($Path)
    try {
        if ($null -eq $zip.GetEntry('Contents/content.hpf')) { throw 'HWPX 기본 구조가 없습니다.' }
        $cells=New-Object 'System.Collections.Generic.List[object]'
        $tableCount=0
        $header=Read-ZipXml $zip 'Contents/header.xml'
        $colors=@{}
        foreach ($cp in $header.SelectNodes('//*[local-name()="charProperties"]/*[local-name()="charPr"]')) {
            $colors[$cp.GetAttribute('id')]=$cp.GetAttribute('textColor')
        }
        $entries=@($zip.Entries | Where-Object {$_.FullName -match '^Contents/section\d+\.xml$'} | Sort-Object {[int]([regex]::Match($_.FullName,'section(\d+)').Groups[1].Value)})
        foreach ($entry in $entries) {
            $xml=Read-ZipXml $zip $entry.FullName
            foreach ($table in $xml.SelectNodes('//*[local-name()="tbl"]')) {
                $tableCount++
                if ($table.GetAttribute('colCnt') -ne '1') { throw '생성 문서의 표가 한 열이 아닙니다. HTML 불러오기 결과를 확인하세요.' }
                foreach ($cell in $table.SelectNodes('./*[local-name()="tr"]/*[local-name()="tc"]')) { $cells.Add($cell) }
            }
        }
        if ($tableCount -ne 1 -or $cells.Count -ne $Trips.Count) {
            throw "표 검증 실패: 표 $tableCount 개, 칸 $($cells.Count) 개 / 예상 표 1개, 칸 $($Trips.Count) 개."
        }
        for ($i=0;$i -lt $cells.Count;$i++) {
            $actual=(@($cells[$i].SelectNodes('.//*[local-name()="t"]') | ForEach-Object {$_.InnerText}) -join '') -replace '\s+',''
            $expected=($Trips[$i].Text -replace '\s+','')
            if ($actual -cne $expected) { throw "표 내용/역순 검증 실패: 출력 $($i+1)번째 칸, 엑셀 순번 $($Trips[$i].순번)." }
            if ($Trips[$i].HasError) {
                $textRuns=@($cells[$i].SelectNodes('.//*[local-name()="run"][.//*[local-name()="t"]]'))
                if ($textRuns.Count -eq 0) { throw "출력 $($i+1)번째 오류 칸에 글자가 없습니다." }
                foreach ($run in $textRuns) {
                    $color=[string]$colors[$run.GetAttribute('charPrIDRef')]
                    if ($color.ToUpperInvariant() -ne '#FF0000') { throw "출력 $($i+1)번째 오류 칸의 빨간색 검증에 실패했습니다." }
                }
            }
        }
    } finally { $zip.Dispose() }
}
$exitCode=1
try {
    $TempDir = Join-Path ([IO.Path]::GetTempPath()) ('TripReport_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $TempDir -ErrorAction Stop | Out-Null
    Write-Log '출장보고서: 확인 내역만 / 오류 칸 빨간 글씨 / 오류 사유 표시 / 한 칸당 출장 하나 / 출발 날짜와 시간 오름차순'
    $Stage='설정 및 직위 목록 읽기'
    $config=Get-Content -LiteralPath (Join-Path $Base '설정.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($config.records -ne '확인') { throw '이 버전은 확인 내역 전용입니다. 설정.json의 records를 확인으로 설정하세요.' }
    if ([int]$config.status_column -lt 1) { throw 'status_column은 1 이상이어야 합니다.' }
    if ([double]$config.font_size -lt 8 -or [double]$config.font_size -gt 24) { throw 'font_size는 8~24여야 합니다.' }
    if (($config.PSObject.Properties.Name -contains 'sort_order') -and $config.sort_order -ne 'start_datetime_asc') {
        throw 'sort_order는 start_datetime_asc로 설정하세요.'
    }
    # Legacy reverse_order is intentionally ignored: sort by parsed departure datetime.
    $script:PositionMap=Read-PositionMap (Join-Path $Base '직위목록.csv')
    $files=@(Get-ChildItem -LiteralPath (Join-Path $Base '출장내역') -File | Where-Object {$_.Extension -in @('.xlsx','.xlsm') -and -not $_.Name.StartsWith('~$')} | Sort-Object Name)
    if ($files.Count -eq 0) { throw '출장내역 폴더에 .xlsx 또는 .xlsm 파일을 넣어 주세요.' }
    foreach ($file in $files) {
        $dest=$null
        try {
            $Stage='엑셀 읽기'
            Write-Log ('읽는 파일: '+$file.Name)
            $trips=@(Read-Trips $file.FullName $config)
            if ($trips.Count -eq 0) { Write-Log '선택한 종류의 출장 내역이 없어 건너뜁니다.'; continue }
            # Valid departures first, then chronological order, then original input order.
            # SourceOrder makes equal timestamps deterministic on Windows PowerShell 5.1.
            $trips=@($trips | Sort-Object -Property @(
                @{Expression={ if ($null -eq $_.StartDateTime) { 1 } else { 0 } }; Ascending=$true},
                @{Expression={ if ($null -eq $_.StartDateTime) { [datetime]::MaxValue } else { $_.StartDateTime } }; Ascending=$true},
                @{Expression={ $_.SourceOrder }; Ascending=$true}
            ))
            Write-Log '정렬: 출발 날짜와 시간 오름차순 / 출발일자 오류 내역은 마지막 / 같은 시각은 원본 순서 유지' 
            $errorCount=@($trips | Where-Object {$_.HasError}).Count
            if ($errorCount -gt 0) {
                $Warnings+=$errorCount
                Write-Log "확인 내역 $($trips.Count)건 중 오류 $errorCount 건: 해당 칸 전체를 빨간 글씨로 표시합니다."
            }
            $stem=$file.BaseName+"_출장보고서_$Stamp"
            $htmlPath=Join-Path $TempDir ($stem+'.html')
            $Stage='임시 HTML 작성'
            Write-TableHtml $trips $config $htmlPath
            Write-Log "출장 $($trips.Count)개 / 첫 순번 $($trips[0].순번) / 마지막 순번 $($trips[-1].순번)"
            $Stage='한글 실행'
            if ($null -eq $Hwp) {
                try { $Hwp=New-Object -ComObject HWPFrame.HwpObject }
                catch { throw '한글 COM 객체를 만들지 못했습니다. 데스크톱 한글 설치와 32/64비트 실행을 확인하세요.' }
                $Hwp.XHwpWindows.Item(0).Visible=$true
            }
            $Stage='HTML 표 불러오기'
            $Hwp.Clear(1) | Out-Null
            if (-not $Hwp.Open($htmlPath,'HTML','')) { throw '한글에서 중간 HTML 표를 불러오지 못했습니다. 파일 접근 확인창을 확인하세요.' }
            $Stage='페이지 및 글자 설정'
            try { Set-PageAndFont $config }
            catch {
                Write-Log ('서식 경고: '+$_.Exception.Message+' / HTML의 기본 서식으로 저장을 계속합니다.')
                $Warnings++
            }
            $dest=Join-Path $OutDir ($stem+'.hwpx')
            $Stage='최종 경로에 HWPX 저장'
            Write-Log ('저장 시도: '+$dest)
            if (-not $Hwp.SaveAs($dest,'HWPX','')) { throw 'HWPX 저장에 실패했습니다. 파일 접근 확인창, 한글 버전, 결과 폴더 쓰기 권한을 확인하세요.' }
            # Close the document before opening its ZIP package. Never move an open HWPX.
            $Stage='저장 문서 닫기'
            $Hwp.Clear(1) | Out-Null
            $Stage='저장 파일 확인'
            $saved=$false
            for ($retry=0; $retry -lt 10; $retry++) {
                if ((Test-Path -LiteralPath $dest -PathType Leaf) -and (Get-Item -LiteralPath $dest).Length -gt 0) {
                    $saved=$true
                    break
                }
                Start-Sleep -Milliseconds 300
            }
            if (-not $saved) { throw '한글에서 저장 완료를 반환했지만, 최종 경로에서 0바이트보다 큰 HWPX를 찾지 못했습니다.' }
            $Stage='표 내용 및 출력 순서 검증'
            try {
                if ($errorCount -gt 0) {
                    $backup=Join-Path $TempDir ($stem+'_before_color.hwpx')
                    Copy-Item -LiteralPath $dest -Destination $backup -ErrorAction Stop
                    try { Set-HwpxErrorColors $dest $trips }
                    catch {
                        Copy-Item -LiteralPath $backup -Destination $dest -Force -ErrorAction Stop
                        throw
                    }
                }
                Test-HwpxTable $dest $trips
                Write-Log "완료: $dest"
                Write-Log "표 1개 / 칸 $($trips.Count)개 / 각 칸 내용, 출력 순서 및 오류 칸 빨간색 검증 통과"
            } catch {
                $Warnings++
                Write-Log ('검증 경고: '+$_.Exception.Message)
                Write-Log ('HWPX는 삭제하지 않았습니다. 한글에서 열어 내용과 표를 확인하세요: '+$dest)
            }
            $Succeeded++
        } catch {
            $Failed++
            Write-Log ("실패: {0} / 단계: {1}`r`n{2}`r`n위치: {3}" -f $file.Name,$Stage,$_.Exception.Message,$_.InvocationInfo.PositionMessage)
            if ($dest -and (Test-Path -LiteralPath $dest)) { Write-Log ('저장 파일은 보존했습니다. 정상 문서인지 확인하세요: '+$dest) }
            # Preserve any saved HWPX; temporary cleanup is limited to the HTML directory.
        }
    }
    Write-Log "처리 완료: 저장 $Succeeded 파일 / 실패 $Failed 파일 / 경고 $Warnings 건"
    if ($Warnings -gt 0) { Write-Log '경고가 있습니다. 생성된 문서를 열어 확인하고, 문제 발생 시 실행창을 캡처해 주세요.' }
    if ($Failed -eq 0 -and $Succeeded -gt 0) {
        if ($Warnings -gt 0) { $exitCode=3 } else { $exitCode=0 }
    }
} catch {
    Write-Log ('오류 / 단계: '+$Stage+' / '+$_.Exception.Message)
    Write-Log ('위치: '+$_.InvocationInfo.PositionMessage)
} finally {
    if ($null -ne $Hwp) {
        try { $Hwp.Clear(1) | Out-Null; $Hwp.Quit() | Out-Null } catch {}
        try { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($Hwp) | Out-Null } catch {}
    }
    if ($null -ne $TempDir -and (Test-Path -LiteralPath $TempDir)) {
        try { Remove-Item -LiteralPath $TempDir -Recurse -Force -ErrorAction Stop }
        catch { Write-Host ("임시 파일 정리에 실패했습니다. 다음 폴더를 직접 삭제해 주세요: {0}`n{1}" -f $TempDir,$_.Exception.Message) }
    }
    try { $RunMutex.ReleaseMutex(); $RunMutex.Dispose() } catch {}
    Write-Host "`nHWPX 결과 폴더: $OutDir"
    if ($Warnings -gt 0 -or $Failed -gt 0 -or $exitCode -ne 0) {
        try {
            Add-Type -AssemblyName System.Windows.Forms
            [void][System.Windows.Forms.MessageBox]::Show(
                "저장 $Succeeded 파일 / 실패 $Failed 파일 / 경고 $Warnings 건`r`n보고서의 빨간 글씨 칸과 실행창을 확인하세요.",
                '출장보고서 오류/경고',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning)
        } catch { Write-Host '알림창을 표시하지 못했습니다. 실행창의 오류/경고를 확인하세요.' }
    }
}
exit $exitCode
