@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 출장보고서 v4.1 64비트 오류 점검
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
"%PS%" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0출장보고서생성.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
echo 종료 코드: %RESULT%
echo 오류나 경고가 있으면 위 화면을 캡처해 주세요. TXT 기록 파일은 생성하지 않습니다.
pause
exit /b %RESULT%
