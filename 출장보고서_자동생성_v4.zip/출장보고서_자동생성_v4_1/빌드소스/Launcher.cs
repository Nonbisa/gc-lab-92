﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
[assembly: AssemblyTitle("Trip Report Launcher")]
[assembly: AssemblyVersion("2.0.0.0")]
internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        int result = 1;
        try
        {
            string folder = AppDomain.CurrentDomain.BaseDirectory;
            string script = Path.Combine(folder, "출장보고서생성.ps1");
            if (!File.Exists(script))
                throw new FileNotFoundException("EXE와 출장보고서생성.ps1을 같은 폴더에 두세요.", script);
            string windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            bool use64 = args.Length > 0 && args[0] == "--64";
            string shell = Path.Combine(windows, use64 ? "System32" : "SysWOW64", @"WindowsPowerShell\v1.0\powershell.exe");
            if (!File.Exists(shell))
                shell = Path.Combine(windows, "System32", @"WindowsPowerShell\v1.0\powershell.exe");
            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = shell;
            start.Arguments = "-NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File \"" + script + "\"";
            start.WorkingDirectory = folder;
            start.UseShellExecute = false;
            Console.Title = "출장보고서 자동생성 v2";
            using (Process process = Process.Start(start))
            {
                process.WaitForExit();
                result = process.ExitCode;
            }
            Console.WriteLine(result == 0 ? "\n생성을 완료했습니다." : "\n작업이 완료되지 않았습니다. 보고서 결과 폴더의 처리기록을 확인하세요.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("실행 오류: " + ex.Message);
        }
        Console.WriteLine("\n종료하려면 아무 키나 누르세요.");
        try { Console.ReadKey(true); } catch { }
        return result;
    }
}
