const DEFAULT_REMINDER_DELAY_MINUTES=59;
const DEFAULTS={reminderEnabled:true,reminderDelayMinutes:DEFAULT_REMINDER_DELAY_MINUTES};
const SEOUL_TIME_ZONE='Asia/Seoul';
function seoulParts(t){return Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:SEOUL_TIME_ZONE,year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',second:'numeric',hourCycle:'h23'}).formatToParts(new Date(t)).map(part=>[part.type,part.value]));}
function seoulTimeToTimestamp(year,month,day,hour,minute){
  const utcGuess=Date.UTC(year,month-1,day,hour,minute);
  const p=seoulParts(utcGuess);
  const representedUtc=Date.UTC(Number(p.year),Number(p.month)-1,Number(p.day),Number(p.hour),Number(p.minute),Number(p.second));
  return utcGuess-(representedUtc-utcGuess);
}
function recordedAtTimestamp(dateValue,timeValue){
  const date=String(dateValue||'').replace(/\D/g,'');
  const match=String(timeValue||'').trim().match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if(date.length!==8||!match)return null;
  const year=Number(date.slice(0,4)),month=Number(date.slice(4,6)),day=Number(date.slice(6,8));
  const hour=Number(match[1]),minute=Number(match[2]),second=Number(match[3]||0);
  const check=new Date(Date.UTC(year,month-1,day));
  if(check.getUTCFullYear()!==year||check.getUTCMonth()!==month-1||check.getUTCDate()!==day||hour>23||minute>59||second>59)return null;
  return seoulTimeToTimestamp(year,month,day,hour,minute);
}
function reminderDelayMinutes(value){
  const minutes=Number(value);
  return Number.isInteger(minutes)&&minutes>=1&&minutes<=1440?minutes:DEFAULT_REMINDER_DELAY_MINUTES;
}
function reminderDueAt(now,delayMinutes=DEFAULT_REMINDER_DELAY_MINUTES){
  const dueAt=now+reminderDelayMinutes(delayMinutes)*60*1000,p=seoulParts(dueAt);
  const weekday=new Date(Date.UTC(Number(p.year),Number(p.month)-1,Number(p.day))).getUTCDay();
  const hour=Number(p.hour);
  if(weekday===0||weekday===6||hour<9||hour>=18)return dueAt;
  return seoulTimeToTimestamp(Number(p.year),Number(p.month),Number(p.day),18,0);
}
function dayKey(t){return new Intl.DateTimeFormat('en-CA',{timeZone:SEOUL_TIME_ZONE,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(t));}
function recordTransition(old,now,source,delayMinutes=DEFAULT_REMINDER_DELAY_MINUTES){
  return {id:String(now)+'-'+String((old?.sequence||0)+1),sequence:(old?.sequence||0)+1,day:dayKey(now),startedAt:now,dueAt:reminderDueAt(now,delayMinutes),state:'pending',source};
}
if(typeof module!=='undefined')module.exports={DEFAULTS,DEFAULT_REMINDER_DELAY_MINUTES,dayKey,recordedAtTimestamp,reminderDelayMinutes,reminderDueAt,recordTransition};
