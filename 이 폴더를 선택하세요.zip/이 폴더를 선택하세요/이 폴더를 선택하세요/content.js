(()=>{
  if(globalThis.__soilGridReminderWatch)return;globalThis.__soilGridReminderWatch=true;
    const prefix='mainframe.WorkFrame.tatAtdc03001P15.form.div.form.grdList.body.gridrow_';
    const selector=`[id^="${prefix}"]`;
    const timeCell=/\.gridrow_\d+\.cell_\d+_1:text$/;
    let lastSignature='',scanTimer=0;
    function isGridNode(node){
      const element=node?.nodeType===1?node:node?.parentElement;
      if(!element)return false;
      return element.id?.startsWith(prefix)||Boolean(element.closest?.(selector))||Boolean(element.querySelector?.(selector));
    }
    function isShown(element){const rect=element.getBoundingClientRect(),style=getComputedStyle(element);return rect.width>0&&rect.height>0&&style.display!=='none'&&style.visibility!=='hidden';}
    function scanGrid(){
      const cells=[...document.querySelectorAll('.nexacontentsbox')].filter(element=>element.id.startsWith(prefix)&&timeCell.test(element.id));
      const shown=cells.filter(isShown);
      if(!shown.length){lastSignature='';return;}
      const signature=shown.map(element=>element.id+'='+(element.textContent||'').trim()).sort().join('|');
      if(signature===lastSignature)return;
      lastSignature=signature;
      chrome.runtime.sendMessage({type:'LOCAL_GRID_OPEN'}).catch(()=>{});
    }
    function queueScan(force=false){if(force)lastSignature='';if(scanTimer)clearTimeout(scanTimer);scanTimer=setTimeout(()=>{scanTimer=0;scanGrid();},100);}
    const observer=new MutationObserver(records=>{
      const relevant=records.some(record=>{
        if(record.type==='characterData')return isGridNode(record.target);
        if(record.type==='attributes')return isGridNode(record.target);
        return Boolean(record.target?.nodeType===1&&record.target.id?.startsWith(prefix))||[...record.addedNodes,...record.removedNodes].some(isGridNode);
      });
      if(relevant)queueScan();
    });
    observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['style','class']});
    document.addEventListener('change',event=>{
      const inRecordPopup=event.composedPath().some(node=>node instanceof Element&&node.id?.includes('tatAtdc03001P15'));
      if(!inRecordPopup)return;
      queueScan(true);
      setTimeout(()=>queueScan(true),500);
    },true);
    scanGrid();
  })();
