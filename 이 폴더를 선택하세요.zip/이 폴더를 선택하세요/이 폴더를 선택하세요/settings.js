const keys=['reminderEnabled'];
const SESSION_CHECK_INTERVAL_MS=5*60*1000;
const $=id=>document.getElementById(id);
const time=t=>new Date(t).toLocaleString('ko-KR',{timeZone:'Asia/Seoul',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});
let stateSnapshot=null;
function renderSessionState(){
 if(!stateSnapshot)return;
 const a=stateSnapshot.insarangAutoState||{},labels={off:'권한 없음',waiting:'확인 완료',extended:'연장 성공',failed:'연장 실패',expired:'로그인 만료',not_logged_in:'로그인 필요',no_tab:'인사랑 탭 없음',timer_unknown:'남은 시간 인식 불가',unavailable:'연장 버튼 확인 필요',cooldown:'재시도 대기',extending:'연장 확인 중'};
 const parts=[labels[a.status]||'대기 중'];
 if(Number.isFinite(a.remaining))parts.push(Math.ceil(a.remaining/60)+'분 남음');
 if(a.lastSuccess)parts.push('성공 '+time(a.lastSuccess));
 let nextCheck='';
 if(Number.isFinite(a.checkedAt)&&a.status!=='off'){
  const seconds=Math.max(0,Math.ceil((SESSION_CHECK_INTERVAL_MS-(Date.now()-a.checkedAt))/1000));
  nextCheck='다음 자동확인까지 '+Math.floor(seconds/60)+'분 '+String(seconds%60).padStart(2,'0')+'초';
 }
 const status=$('sessionState');status.replaceChildren(document.createTextNode(parts.join(' · ')));
 if(nextCheck)status.append(document.createElement('br'),document.createTextNode(nextCheck));
}
async function render(){const s=await chrome.storage.local.get(null);stateSnapshot=s;for(const k of keys)$(k).checked=s[k]!==false;$('reminderDelayMinutes').value=s.reminderDelayMinutes??59;
 renderSessionState();
 const r=s.record;$('recordState').textContent=s.reminderEnabled===false?'기록 알림 꺼짐':!r?'기록관리 팝업 열기 대기':({pending:'기록시각 기준 예약 '+time(r.dueAt)+' · '+Math.max(0,Math.ceil((r.dueAt-Date.now())/60000))+'분 남음',notified:'알림 처리됨 · '+time(r.dueAt),cancelled:'알림 취소됨 · 팝업을 열어 기록시각 재확인'}[r.state]||r.state)+(s.deliveryError?' · '+s.deliveryError:'');
}
async function send(type,extra={}){const r=await chrome.runtime.sendMessage({type,...extra});if(!r?.ok)throw Error(r?.error||'요청 실패');return r;}
function bind(id,fn){$(id).onclick=async()=>{$(id).disabled=true;try{await fn();await render();}catch(e){$('feedback').textContent=e.message;}finally{$(id).disabled=false;}};}
bind('extend',async()=>{await send('INSARANG_AUTO_EXTEND_NOW');$('feedback').textContent='연장 결과를 확인하세요.';});
for(const k of keys)$(k).onchange=async()=>{const input=$(k);input.disabled=true;try{await send('LOCAL_SAVE',{values:{[k]:input.checked}});$('feedback').textContent=input.checked?'기록 알림을 켰습니다.':'기록 알림을 끄고 예약을 취소했습니다.';}catch(e){$('feedback').textContent=e.message;await render();}finally{input.disabled=false;}};
$('reminderDelayMinutes').onchange=async()=>{const input=$('reminderDelayMinutes');input.disabled=true;try{await send('LOCAL_SAVE',{values:{reminderDelayMinutes:input.value}});$('feedback').textContent='알람 주기를 저장했습니다.';}catch(e){$('feedback').textContent=e.message;await render();}finally{input.disabled=false;}};
bind('test',async()=>{$('feedback').textContent='5초 후 테스트 창을 엽니다.';await send('LOCAL_TEST');});
chrome.storage.onChanged.addListener(()=>render().catch(()=>{}));render().catch(console.error);setInterval(renderSessionState,1000);
