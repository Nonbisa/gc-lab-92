document.getElementById('open').onclick=()=>chrome.runtime.sendMessage({type:'LOCAL_OPEN'}).then(()=>window.close());
document.getElementById('close').onclick=()=>window.close();
document.getElementById('snooze').onclick=async()=>{
  const button=document.getElementById('snooze');button.disabled=true;
  try{const result=await chrome.runtime.sendMessage({type:new URL(location.href).searchParams.get('test')==='1'?'LOCAL_TEST_SNOOZE':'LOCAL_SNOOZE',minutes:5});if(!result?.ok)throw Error(result?.error||'스누즈 예약에 실패했습니다.');window.close();}
  catch(e){button.disabled=false;document.getElementById('text').append(document.createElement('br'),document.createTextNode(e.message));}
};

const recordId=new URL(location.href).searchParams.get("record");
let fitTimer=0;
async function fitWindow(){
  const card=document.getElementById('noticeCard');
  const contentHeight=card.getBoundingClientRect().height+24;
  const frameHeight=Math.max(0,window.outerHeight-window.innerHeight);
  const height=Math.max(300,Math.min(560,Math.ceil(contentHeight+frameHeight+8)));
  try{
    const current=await chrome.windows.getCurrent();
    if(current.id&&Math.abs((current.height||0)-height)>2)await chrome.windows.update(current.id,{height});
  }catch{}
}
function queueFit(){clearTimeout(fitTimer);fitTimer=setTimeout(fitWindow,50);}
async function renderNotice(){
  const s=await chrome.storage.local.get(['record','reminderDelayMinutes']);
  if(recordId&&(s.record?.id!==recordId||s.record?.state==='cancelled')){window.close();return;}
  const minutes=recordId&&Number.isInteger(s.record?.reminderDelayMinutes)?s.record.reminderDelayMinutes:s.reminderDelayMinutes;
  if(!Number.isInteger(minutes))return;
  document.getElementById('text').replaceChildren(document.createTextNode('초과근무 확인 후 '+minutes+'분이 지났습니다.'),document.createElement('br'),document.createTextNode('인사랑에서 초과근무를 기록해주세요.'));
  queueFit();
}
new ResizeObserver(queueFit).observe(document.body);
chrome.storage.onChanged.addListener(()=>renderNotice().catch(()=>{}));renderNotice().catch(()=>{});queueFit();
