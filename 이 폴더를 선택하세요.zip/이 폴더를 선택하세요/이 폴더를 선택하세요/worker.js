importScripts('model.js');
const INSARANG_ORIGIN='https://seoul.insarang.go.kr';
const INSARANG_PERMISSION={origins:[INSARANG_ORIGIN+'/*']};
function isInsarangUrl(url){try{return new URL(url).origin===INSARANG_ORIGIN;}catch{return false;}}
async function insarangConnection(){return {connected:await chrome.permissions.contains(INSARANG_PERMISSION)};}
importScripts('session.js');
function readGridRecordTimes(){
  const shell=window.__INSA_SHELL__;
  if(!shell||typeof shell.findObject!=='function')return [];
  const frame=shell.findObject(obj=>String(obj.name||'').toLowerCase()==='tatatdc03001p15');
  const form=frame?.form,data=form?.dsWrkRecList,date=form?.selectYmd;
  if(!date)return [];
  const records=[];
  if(data){
    for(let row=0;row<data.getRowCount();row++){
      const time=data.getColumn(row,'wrkIfyHm');
      if(time!==''&&time!=null)records.push({date:String(date),time:String(time).trim()});
    }
  }
  if(records.length)return records;
  // The initial view hides 09:00~18:00. Fall back to the expanded grid's visible record-time cells.
  const prefix='mainframe.WorkFrame.tatAtdc03001P15.form.div.form.grdList.body.gridrow_';
  const timeCell=/\.gridrow_(\d+)\.cell_(\d+)_1:text$/;
  for(const element of document.querySelectorAll('.nexacontentsbox')){
    if(!element.id.startsWith(prefix))continue;
    const match=element.id.match(timeCell),time=(element.textContent||'').trim();
    if(match&&match[1]===match[2]&&/^\d{1,2}:\d{2}$/.test(time))records.push({date:String(date),time});
  }
  return records;
}
async function readLatestGridRecordedAt(tabId,frameId){
  for(let attempt=0;attempt<20;attempt++){
    try{
      const [result]=await chrome.scripting.executeScript({target:{tabId,frameIds:[frameId]},world:'MAIN',func:readGridRecordTimes});
      const timestamps=(result?.result||[]).map(record=>recordedAtTimestamp(record.date,record.time)).filter(value=>Number.isFinite(value)&&dayKey(value)===dayKey(Date.now()));
      if(timestamps.length)return Math.max(...timestamps);
    }catch{}
    await new Promise(resolve=>setTimeout(resolve,250));
  }
  return null;
}
async function scheduleFromGrid(tabId,frameId){
  const current=await state();
  if(!current.reminderEnabled)return {ok:true,scheduled:false,message:'기록 알림이 꺼져 있습니다.'};
  const recordedAt=await readLatestGridRecordedAt(tabId,frameId);
  if(recordedAt===null)return {ok:false,scheduled:false,message:'오늘 그리드에서 기록시각을 읽지 못했습니다.'};
  const latest=await state();
  if(latest.record?.recordedAt===recordedAt&&latest.record.state!=='cancelled')return {ok:true,scheduled:true,unchanged:true,recordedAt};
  const record={...recordTransition(latest.record,recordedAt,{source:'record-grid'},latest.reminderDelayMinutes),recordedAt,reminderDelayMinutes:reminderDelayMinutes(latest.reminderDelayMinutes)};
  await clearSystemNotification(latest.record);
  await chrome.storage.local.set({record,deliveryError:''});
  await reconcile();
  return {ok:true,scheduled:true,recordedAt};
}
const REMINDER='insarang-record-due';
const TEST_SNOOZE_REMINDER='insarang-test-snooze';
const SYSTEM_NOTIFICATION_PREFIX='insarang-record-';
let queue=Promise.resolve();
function serial(fn){const next=queue.catch(()=>{}).then(fn);queue=next;return next;}
async function state(){const s=await chrome.storage.local.get(null);return {...DEFAULTS,...s};}
async function openInsarang(){const tabs=await chrome.tabs.query({url:INSARANG_ORIGIN+'/nexin/index.html*'});if(tabs.length){await chrome.tabs.update(tabs[0].id,{active:true});await chrome.windows.update(tabs[0].windowId,{focused:true});}else await chrome.tabs.create({url:INSARANG_ORIGIN+'/nexin/index.html'});}
async function clearSystemNotification(record){if(record?.notificationId)await chrome.notifications.clear(record.notificationId).catch(()=>{});}
async function showSystemNotification(record,test=false){
  const id=SYSTEM_NOTIFICATION_PREFIX+(test?'test-'+Date.now():record.id);
  const minutes=reminderDelayMinutes(record.reminderDelayMinutes);
  await chrome.notifications.create(id,{type:'basic',iconUrl:'icon.png',title:test?'초과근무 알라미 테스트':'초과근무 기록 알림',message:test?'설정 주기: '+minutes+'분':'초과근무 확인 후 '+minutes+'분이 지났습니다.',contextMessage:'클릭하면 인사랑을 엽니다.',buttons:[{title:'5분 후 다시 알림'},{title:'인사랑 열기'}],priority:2,requireInteraction:true});
  return id;
}
async function snooze(minutes){
  if(!Number.isInteger(minutes)||minutes<1||minutes>60)throw Error('스누즈 시간은 1~60분 사이로 설정하세요.');
  const s=await state(),r=s.record;
  if(!r||r.state!=='notified')throw Error('다시 알릴 알림이 없습니다.');
  const snoozedUntil=Date.now()+minutes*60*1000;
  await clearSystemNotification(r);
  await chrome.storage.local.set({record:{...r,state:'pending',dueAt:snoozedUntil,snoozedUntil,snoozeMinutes:minutes,notificationId:''},deliveryError:''});
  await reconcile();
  return {ok:true,message:minutes+'분 후 다시 알려드립니다.'};
}
async function testSnooze(minutes){
  if(!Number.isInteger(minutes)||minutes<1||minutes>60)throw Error('스누즈 시간은 1~60분 사이로 설정하세요.');
  await chrome.alarms.create(TEST_SNOOZE_REMINDER,{when:Date.now()+minutes*60*1000});
  return {ok:true,message:minutes+'분 후 테스트 알림을 다시 표시합니다.'};
}
async function deliver(test=false,testDelayMs=test?5000:0){
  if(testDelayMs)await new Promise(resolve=>setTimeout(resolve,testDelayMs));
  const s=await state(),r=s.record;
  if(!test&&(!s.reminderEnabled||!r||r.state!=='pending'||r.dueAt>Date.now()))return;
  const notificationRecord=test?{id:'test',reminderDelayMinutes:s.reminderDelayMinutes}:r;
  let notificationId='',systemError='';
  try{notificationId=await showSystemNotification(notificationRecord,test);}catch(e){systemError='시스템 알림: '+e.message;}
  const url=chrome.runtime.getURL('notice.html')+(test?'?test=1':'?record='+encodeURIComponent(r.id));
  let popupError='';
  try{await chrome.windows.create({url,type:'popup',width:460,height:360,focused:true});}
  catch(e){popupError='팝업: '+e.message;}
  const deliveryError=[systemError,popupError].filter(Boolean).join(' · ');
  if(!test)await chrome.storage.local.set({record:{...r,state:'notified',notifiedAt:Date.now(),notificationId},deliveryError});
  return {ok:!deliveryError,delivered:Boolean(notificationId)||!popupError,error:deliveryError||undefined};
}
async function reconcile(){const s=await state(),r=s.record;if(s.reminderEnabled&&r?.state==='pending'){const baseAt=Number.isFinite(r.recordedAt)?r.recordedAt:r.startedAt;const delayMinutes=reminderDelayMinutes(s.reminderDelayMinutes),dueAt=Number.isFinite(r.snoozedUntil)?r.snoozedUntil:Number.isFinite(baseAt)?reminderDueAt(baseAt,delayMinutes):r.dueAt;if(dueAt!==r.dueAt||r.reminderDelayMinutes!==delayMinutes)await chrome.storage.local.set({record:{...r,dueAt,reminderDelayMinutes:delayMinutes}});if(dueAt<=Date.now())await deliver();else await chrome.alarms.create(REMINDER,{when:dueAt});}else await chrome.alarms.clear(REMINDER);}
async function initialize(){
  await chrome.storage.local.remove(['desktop','popup','badge','recordButtonId','pickingUntil','insarangAutoExtend']);
  const s=await chrome.storage.local.get(null),missing={};for(const [k,v]of Object.entries(DEFAULTS))if(s[k]===undefined)missing[k]=v;
  if(Object.keys(missing).length)await chrome.storage.local.set(missing);
  await reconcile();
}
chrome.runtime.onInstalled.addListener(()=>serial(initialize));
chrome.runtime.onStartup.addListener(()=>serial(initialize));
chrome.alarms.onAlarm.addListener(a=>{if(a.name===REMINDER)serial(reconcile);if(a.name===TEST_SNOOZE_REMINDER)serial(()=>deliver(true,0));});
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if(!m?.type?.startsWith('LOCAL_'))return;
  const page=Boolean(sender.tab&&isInsarangUrl(sender.url));
  const own=String(sender.url||'').startsWith(chrome.runtime.getURL(''));
  if(!page&&!own){reply({ok:false,error:'허용되지 않은 요청'});return;}
  serial(async()=>{
    if(m.type==='LOCAL_GRID_OPEN'&&page)return scheduleFromGrid(sender.tab.id,sender.frameId);
    if(!own)throw Error('설정 화면에서만 실행할 수 있습니다.');
    if(m.type==='LOCAL_SAVE'){
      const v={};
      if(typeof m.values?.reminderEnabled==='boolean')v.reminderEnabled=m.values.reminderEnabled;
      if(Object.hasOwn(m.values||{},'reminderDelayMinutes')){
        const minutes=Number(m.values.reminderDelayMinutes);
        if(!Number.isInteger(minutes)||minutes<1||minutes>1440)throw Error('알람 주기는 1~1440분 사이의 정수로 입력하세요.');
        v.reminderDelayMinutes=minutes;
      }
      if(v.reminderEnabled===false){
        const current=await state();
        await chrome.alarms.clear(REMINDER);
        await clearSystemNotification(current.record);
        if(current.record)await chrome.storage.local.set({record:{...current.record,state:'cancelled',cancelledAt:Date.now()},deliveryError:''});
      }
      await chrome.storage.local.set(v);await reconcile();return {ok:true};
    }
    if(m.type==='LOCAL_TEST')return deliver(true);
    if(m.type==='LOCAL_SNOOZE')return snooze(Number(m.minutes));
    if(m.type==='LOCAL_TEST_SNOOZE')return testSnooze(Number(m.minutes));
    if(m.type==='LOCAL_OPEN'){await openInsarang();return {ok:true};}
    throw Error('알 수 없는 요청');
  }).then(reply,e=>reply({ok:false,error:e.message}));return true;
});
chrome.notifications.onClicked.addListener(id=>{if(id.startsWith(SYSTEM_NOTIFICATION_PREFIX))serial(openInsarang).catch(()=>{});});
chrome.notifications.onButtonClicked.addListener((id,index)=>{if(!id.startsWith(SYSTEM_NOTIFICATION_PREFIX))return;if(index===0)serial(()=>id.startsWith(SYSTEM_NOTIFICATION_PREFIX+'test-')?testSnooze(5):snooze(5)).catch(()=>{});else serial(openInsarang).catch(()=>{});});
serial(initialize).catch(console.error);
