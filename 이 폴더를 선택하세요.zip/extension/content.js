(()=>{
  if(globalThis.__soilLocal)return;globalThis.__soilLocal=true;
  const compact=t=>String(t||'').replace(/\s+/g,'');
  function control(target){if(!(target instanceof Element))return null;return target.closest('button,input[type="button"],a,[role="button"],[id*=".btn"]');}
  function matches(el){if(!el)return false;const text=compact(el.getAttribute('aria-label')||el.innerText||el.value||el.title);return text==='확인'&&/^mainframe\.WorkFrame\.tatAtdc03001P15\.form\.div\.form\.grdList\.body\.gridrow_\d+\.cell_\d+_1\.cellbutton:icontext$/.test(el.id);}
  document.addEventListener('click',e=>{
    if(!e.isTrusted)return;
    let el=control(e.target);
    // Nexacro text child clicks resolve to the button container through the event path.
    for(const node of e.composedPath())if(node instanceof Element&&matches(node)){el=node;break;}
    if(!matches(el)||el.disabled||el.getAttribute('aria-disabled')==='true')return;
    chrome.runtime.sendMessage({type:'LOCAL_RECORD'}).catch(()=>{});
  },true);
})();
