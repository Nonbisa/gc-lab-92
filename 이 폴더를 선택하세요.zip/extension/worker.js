importScripts('model.js');
const INSARANG_ORIGIN='https://seoul.insarang.go.kr';
const INSARANG_PERMISSION={origins:[INSARANG_ORIGIN+'/*']};
function isInsarangUrl(url){try{return new URL(url).origin===INSARANG_ORIGIN;}catch{return false;}}
async function insarangConnection(){return {connected:await chrome.permissions.contains(INSARANG_PERMISSION)};}
importScripts('session.js');
const GRID_CONFIRM_BUTTON_PREFIX='mainframe.WorkFrame.tatAtdc03001P15.form.div.form.grdList.body.gridrow_';
function inspectGridConfirmButton(prefix){
  const elements=[...document.querySelectorAll('.nexacontentsbox')].filter(element=>element.id.startsWith(prefix)&&element.id.endsWith('.cellbutton:icontext'));
  if(!elements.length)return {status:'not_found'};
  const shell=window.__INSA_SHELL__;
  if(!shell||typeof shell.findObject!=='function')return {status:'shell_missing'};
  const frame=shell.findObject(obj=>String(obj.name||'').toLowerCase()==='tatatdc03001p15');
  const form=frame?.form,grid=form?.div?.form?.grdList;
  if(!form||!grid||typeof form.div_grdList_oncellclick!=='function')return {status:'handler_missing'};
  if(form.sToday!=form.selectYmd)return {status:'date_mismatch'};
  const data=form.dsWrkRecList;
  if(!data)return {status:'row_missing'};
  const ready=[];let failure='not_found';
  for(const element of elements){
    const match=/\.gridrow_(\d+)\.cell_(\d+)_(\d+)\.cellbutton:icontext$/.exec(element.id);
    if(!match||Number(match[1])!==Number(match[2])||Number(match[3])!==1)continue;
    const row=Number(match[1]),cell=Number(match[3]);
    if(row<0||row>=data.getRowCount()){failure='row_missing';continue;}
    if(data.getColumn(row,'wrkTimSeHh')!=form.dbTimeHh){failure='hour_mismatch';continue;}
    const recordedAt=data.getColumn(row,'wrkIfyHm');
    if(recordedAt!==''&&recordedAt!=null){failure='already_recorded';continue;}
    const rect=element.getBoundingClientRect(),style=getComputedStyle(element);
    if(!rect.width||!rect.height||style.display==='none'||style.visibility==='hidden'){failure='not_visible';continue;}
    if((element.textContent||'').trim()!=='확인'){failure='unexpected';continue;}
    if(element.getAttribute('aria-disabled')==='true'){failure='disabled';continue;}
    ready.push({id:element.id,row,cell});
  }
  if(ready.length>1)return {status:'ambiguous'};
  return ready.length===1?{status:'ready',...ready[0]}:{status:failure};
}
function invokeGridConfirmHandler(id,row,cell){
  const element=document.getElementById(id);
  if(!element)return {status:'not_found'};
  const rect=element.getBoundingClientRect(),style=getComputedStyle(element);
  if(!rect.width||!rect.height||style.display==='none'||style.visibility==='hidden')return {status:'not_visible'};
  if(!element.classList.contains('nexacontentsbox')||(element.textContent||'').trim()!=='확인')return {status:'unexpected'};
  if(element.getAttribute('aria-disabled')==='true')return {status:'disabled'};
  const shell=window.__INSA_SHELL__;
  if(!shell||typeof shell.findObject!=='function')return {status:'shell_missing'};
  const frame=shell.findObject(obj=>String(obj.name||'').toLowerCase()==='tatatdc03001p15');
  const form=frame?.form,grid=form?.div?.form?.grdList,handler=form?.div_grdList_oncellclick;
  if(!form||!grid||typeof handler!=='function')return {status:'handler_missing'};
  const data=form.dsWrkRecList;
  if(!data||row<0||row>=data.getRowCount())return {status:'row_missing'};
  if(form.sToday!=form.selectYmd)return {status:'date_mismatch'};
  if(data.getColumn(row,'wrkTimSeHh')!=form.dbTimeHh)return {status:'hour_mismatch'};
  const recordedAt=data.getColumn(row,'wrkIfyHm');
  if(recordedAt!==''&&recordedAt!=null)return {status:'already_recorded'};
  handler.call(form,grid,{cell,row});
  return {status:'invoked',row,cell};
}
async function clickGridConfirmButton(){
  const [tab]=await chrome.tabs.query({active:true,lastFocusedWindow:true});
  if(!tab||!isInsarangUrl(tab.url))return {ok:false,error:'활성 탭에서 서울 인사랑을 열어 주세요.'};
  const frames=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},world:'MAIN',func:inspectGridConfirmButton,args:[GRID_CONFIRM_BUTTON_PREFIX]});
  const ready=frames.filter(frame=>frame.result?.status==='ready');
  if(ready.length>1)return {ok:false,error:'확인 버튼이 여러 프레임에서 발견되어 실행하지 않았습니다.'};
  if(!ready.length){
    const statuses=frames.map(frame=>frame.result?.status);
    const errors={not_found:'그리드에서 확인 버튼을 찾지 못했습니다.',not_visible:'확인 버튼이 화면에 표시되지 않습니다.',disabled:'확인 버튼이 비활성 상태입니다.',unexpected:'확인 셀의 표시 문구가 예상과 다릅니다.',ambiguous:'현재 시간대의 미기록 확인 행이 여러 개라 실행하지 않았습니다.',shell_missing:'인사랑 Nexacro 도우미를 찾지 못했습니다.',handler_missing:'그리드 확인 처리 함수를 찾지 못했습니다.',row_missing:'그리드 행을 찾지 못했습니다.',date_mismatch:'선택 날짜가 오늘이 아니어서 처리하지 않았습니다.',hour_mismatch:'현재 시간대와 다른 행이라 처리하지 않았습니다.',already_recorded:'이미 기록된 행이라 처리하지 않았습니다.'};
    const error=Object.keys(errors).find(status=>statuses.includes(status));
    return {ok:false,error:error?errors[error]:'지정된 확인 버튼을 찾지 못했습니다.'};
  }
  const {row,cell}=ready[0].result;
  const [result]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[ready[0].frameId]},world:'MAIN',func:invokeGridConfirmHandler,args:[ready[0].result.id,row,cell]});
  if(result?.result?.status!=='invoked')return {ok:false,error:'확인 처리 조건이 바뀌었거나 내부 함수를 호출하지 못했습니다.'};
  return {ok:true,message:`${row+1}행 확인 처리 함수를 호출했습니다. 기록 저장 결과를 화면에서 확인하세요.`};
}
const REMINDER='insarang-record-due';
let queue=Promise.resolve();
function serial(fn){const next=queue.catch(()=>{}).then(fn);queue=next;return next;}
async function state(){const s=await chrome.storage.local.get(null);return {...DEFAULTS,...s};}
async function openInsarang(){const tabs=await chrome.tabs.query({url:INSARANG_ORIGIN+'/nexin/index.html*'});if(tabs.length){await chrome.tabs.update(tabs[0].id,{active:true});await chrome.windows.update(tabs[0].windowId,{focused:true});}else await chrome.tabs.create({url:INSARANG_ORIGIN+'/nexin/index.html'});}
async function deliver(test=false){
  if(test)await new Promise(resolve=>setTimeout(resolve,5000));
  const s=await state(),r=s.record;
  if(!test&&(!s.reminderEnabled||!r||r.state!=='pending'||r.dueAt>Date.now()))return;
  const url=chrome.runtime.getURL('notice.html')+(test?'?test=1':'?record='+encodeURIComponent(r.id));
  try{await chrome.windows.create({url,type:'popup',width:460,height:320,focused:true});}
  catch(e){if(!test)await chrome.storage.local.set({deliveryError:e.message});return {ok:false,delivered:false,error:e.message};}
  if(!test)await chrome.storage.local.set({record:{...r,state:'notified',notifiedAt:Date.now()},deliveryError:''});
  return {ok:true,delivered:true};
}
async function reconcile(){const s=await state(),r=s.record;if(s.reminderEnabled&&r?.state==='pending'){const dueAt=Number.isFinite(r.startedAt)?reminderDueAt(r.startedAt):r.dueAt;if(dueAt!==r.dueAt)await chrome.storage.local.set({record:{...r,dueAt}});if(dueAt<=Date.now())await deliver();else await chrome.alarms.create(REMINDER,{when:dueAt});}else await chrome.alarms.clear(REMINDER);}
async function recordClick(source){const s=await state();if(!s.reminderEnabled)return;const r=recordTransition(s.record,Date.now(),source);await chrome.storage.local.set({record:r,deliveryError:''});await reconcile();}
async function initialize(){
  await chrome.storage.local.remove(['desktop','popup','badge','recordButtonId','pickingUntil']);
  const s=await chrome.storage.local.get(null),missing={};for(const [k,v]of Object.entries(DEFAULTS))if(s[k]===undefined)missing[k]=v;
  if(Object.keys(missing).length)await chrome.storage.local.set(missing);
  await reconcile();
}
chrome.runtime.onInstalled.addListener(()=>serial(initialize));
chrome.runtime.onStartup.addListener(()=>serial(initialize));
chrome.alarms.onAlarm.addListener(a=>{if(a.name===REMINDER)serial(reconcile);});
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if(!m?.type?.startsWith('LOCAL_'))return;
  const page=Boolean(sender.tab&&isInsarangUrl(sender.url));
  const own=String(sender.url||'').startsWith(chrome.runtime.getURL(''));
  if(!page&&!own){reply({ok:false,error:'허용되지 않은 요청'});return;}
  serial(async()=>{
    if(m.type==='LOCAL_RECORD'&&page){await recordClick({tabId:sender.tab.id,frameId:sender.frameId});return {ok:true};}
    if(!own)throw Error('설정 화면에서만 실행할 수 있습니다.');
    if(m.type==='LOCAL_CLICK_GRID_CONFIRM'){
      const result=await clickGridConfirmButton();
      if(result.ok)await recordClick({source:'grid-confirm'});
      return result;
    }
    if(m.type==='LOCAL_SAVE'){
      const v={};for(const k of Object.keys(DEFAULTS))if(typeof m.values?.[k]==='boolean')v[k]=m.values[k];
      await chrome.storage.local.set(v);await reconcile();return {ok:true};
    }
    if(m.type==='LOCAL_CANCEL'){const s=await state();if(s.record)await chrome.storage.local.set({record:{...s.record,state:'cancelled'}});await reconcile();return {ok:true};}
    if(m.type==='LOCAL_TEST')return deliver(true);
    if(m.type==='LOCAL_OPEN'){await openInsarang();return {ok:true};}
    throw Error('알 수 없는 요청');
  }).then(reply,e=>reply({ok:false,error:e.message}));return true;
});
serial(initialize).catch(console.error);
