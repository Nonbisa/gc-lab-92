const DEFAULTS={reminderEnabled:true};
const DELAY=59*60*1000;
const SEOUL_TIME_ZONE='Asia/Seoul';
function seoulParts(t){return Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:SEOUL_TIME_ZONE,year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',second:'numeric',hourCycle:'h23'}).formatToParts(new Date(t)).map(part=>[part.type,part.value]));}
function seoulTimeToTimestamp(year,month,day,hour,minute){
  const utcGuess=Date.UTC(year,month-1,day,hour,minute);
  const p=seoulParts(utcGuess);
  const representedUtc=Date.UTC(Number(p.year),Number(p.month)-1,Number(p.day),Number(p.hour),Number(p.minute),Number(p.second));
  return utcGuess-(representedUtc-utcGuess);
}
function reminderDueAt(now){
  const dueAt=now+DELAY,p=seoulParts(dueAt);
  const weekday=new Date(Date.UTC(Number(p.year),Number(p.month)-1,Number(p.day))).getUTCDay();
  const hour=Number(p.hour);
  if(weekday===0||weekday===6||hour<9||hour>=18)return dueAt;
  return seoulTimeToTimestamp(Number(p.year),Number(p.month),Number(p.day),18,0);
}
function dayKey(t){return new Intl.DateTimeFormat('en-CA',{timeZone:SEOUL_TIME_ZONE,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(t));}
function recordTransition(old,now,source){
  return {id:String(now)+'-'+String((old?.sequence||0)+1),sequence:(old?.sequence||0)+1,day:dayKey(now),startedAt:now,dueAt:reminderDueAt(now),state:'pending',source};
}
if(typeof module!=='undefined')module.exports={DEFAULTS,DELAY,dayKey,reminderDueAt,recordTransition};
