document.getElementById('open').onclick=()=>chrome.runtime.sendMessage({type:'LOCAL_OPEN'}).then(()=>window.close());
document.getElementById('close').onclick=()=>window.close();

const recordId=new URL(location.href).searchParams.get("record");
async function closeStale(){if(!recordId)return;const s=await chrome.storage.local.get("record");if(s.record?.id!==recordId||s.record?.state==="cancelled")window.close();}
chrome.storage.onChanged.addListener(()=>closeStale().catch(()=>{}));closeStale().catch(()=>{});
