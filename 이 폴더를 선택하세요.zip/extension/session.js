// Only the observed session-extension button is actionable; no authentication data is read.
const INSARANG_AUTO_ALARM='soilpilot-insarang-session';
const INSARANG_AUTO_CHECK_MINUTES=10;
const INSARANG_EXTEND_THRESHOLD_SECONDS=30*60;
let insarangAutoBusy=false;
function insarangSessionInPage(action='read',force=false,thresholdSeconds=30*60){
  if(location.origin!=='https://seoul.insarang.go.kr')return {status:'wrong_origin'};
  const prefix='mainframe.WorkFrame.form.divBottom.form.';
  const button=document.getElementById(prefix+'btnSessionTimeReset');
  const bottom=document.getElementById('mainframe.WorkFrame.form.divBottom');
  const timer=document.getElementById(prefix+'btnSessionTime:text');
  if(!button||!bottom)return {status:'not_logged_in'};
  const shown=e=>{const r=e.getBoundingClientRect();const s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden';};
  if(!shown(button)||button.getAttribute('aria-disabled')==='true')return {status:'unavailable'};
  if(!timer||!shown(timer))return {status:'timer_unknown'};
  const text=(timer.textContent||'').trim();
  let match=text.match(/^(\d{1,3})\s*분(?:\s*(\d{1,2})\s*초)?$/);
  let remaining;
  if(match)remaining=Number(match[1])*60+Number(match[2]||0);
  else{
    match=text.match(/^(\d{1,3}):(\d{2})$/);
    if(!match||Number(match[2])>=60)return {status:'timer_unknown'};
    remaining=Number(match[1])*60+Number(match[2]);
  }
  if(remaining<=0)return {status:'expired',remaining};
  if(action!=='extend'||(!force&&remaining>thresholdSeconds))return {status:'waiting',remaining};
  const app=globalThis.nexacro?.getApplication?.();
  const component=app?.mainframe?.WorkFrame?.form?.divBottom?.form?.btnSessionTimeReset;
  if(component&&(component.enable===false||component.visible===false))return {status:'unavailable',remaining};
  if(component&&typeof component.click==='function'){
    component.click();
    return {status:'attempted',remaining,method:'nexacro-button'};
  }
  // Standard DOM fallback. Verification below must show the timer actually increased.
  for(const type of ['mousedown','mouseup','click'])button.dispatchEvent(new MouseEvent(type,{bubbles:true,cancelable:true,view:window,button:0}));
  return {status:'attempted',remaining,method:'dom-events'};
}
async function configureInsarangAuto(){
  const connection=await insarangConnection();
  await chrome.storage.local.remove('insarangAutoExtend');
  if(!connection.connected){await chrome.alarms.clear(INSARANG_AUTO_ALARM);return;}
  await chrome.alarms.create(INSARANG_AUTO_ALARM,{periodInMinutes:INSARANG_AUTO_CHECK_MINUTES});
  await runInsarangAutoExtend();
}
async function runInsarangAutoExtend(force=false){
  if(insarangAutoBusy)return {status:'busy'};
  insarangAutoBusy=true;
  let old={};
  const save=async data=>{const value={...old,...data,checkedAt:Date.now()};await chrome.storage.local.set({insarangAutoState:value});return value;};
  try{
    const stored=await chrome.storage.local.get('insarangAutoState');old=stored.insarangAutoState||{};
    if(!(await insarangConnection()).connected)return save({status:'off',remaining:null});
    const tabs=(await chrome.tabs.query({url:INSARANG_PERMISSION.origins})).filter(t=>isInsarangUrl(t.url)&&!t.discarded);
    if(!tabs.length)return save({status:'no_tab',remaining:null});
    const read=async(tabId,action='read')=>{
      const out=await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},world:'MAIN',func:insarangSessionInPage,args:[action,force,INSARANG_EXTEND_THRESHOLD_SECONDS]});
      return out[0]?.result||{status:'unavailable'};
    };
    const candidates=[];let lastStatus='not_logged_in';
    for(const tab of tabs){try{const info=await read(tab.id);if(info.status==='waiting')candidates.push({tabId:tab.id,...info});else lastStatus=info.status;}catch{lastStatus='unavailable';}}
    if(!candidates.length)return save({status:lastStatus,remaining:null});
    // One attempt across all tabs per cooldown; browser session is shared.
    candidates.sort((a,b)=>a.remaining-b.remaining);
    const chosen=candidates[0];
    if(!force&&chosen.remaining>INSARANG_EXTEND_THRESHOLD_SECONDS)return save({status:'waiting',remaining:chosen.remaining});
    if(Date.now()-(old.lastAttempt||0)<120000)return save({status:old.status==='failed'?'failed':'cooldown',remaining:chosen.remaining});
    old={...old,lastAttempt:Date.now()};await save({status:'extending',remaining:chosen.remaining});
    const attempt=await read(chosen.tabId,'extend');
    if(attempt.status!=='attempted')return save({...attempt});
    for(let i=0;i<6;i++){
      await new Promise(r=>setTimeout(r,1000));
      const after=await read(chosen.tabId);
      if(after.status==='waiting'&&after.remaining>attempt.remaining)return save({status:'extended',remaining:after.remaining,lastSuccess:Date.now(),method:attempt.method});
    }
    return save({status:'failed',remaining:attempt.remaining,error:'시간 증가를 확인하지 못했습니다. 인사랑 화면을 확인하세요.'});
  }catch(e){return save({status:'failed',error:String(e.message).slice(0,200)});}
  finally{insarangAutoBusy=false;}
}
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name===INSARANG_AUTO_ALARM)runInsarangAutoExtend().catch(()=>{});});
chrome.runtime.onInstalled.addListener(()=>configureInsarangAuto().catch(()=>{}));
chrome.runtime.onStartup.addListener(()=>configureInsarangAuto().catch(()=>{}));
chrome.permissions.onRemoved.addListener(()=>configureInsarangAuto().catch(()=>{}));
chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(!['INSARANG_AUTO_CONFIGURE','INSARANG_AUTO_EXTEND_NOW'].includes(message?.type))return;
  if(!String(sender.url||'').startsWith(chrome.runtime.getURL(''))){sendResponse({ok:false,error:'설정 화면에서만 실행할 수 있습니다.'});return;}
  (message.type==='INSARANG_AUTO_CONFIGURE'?configureInsarangAuto():runInsarangAutoExtend(true))
    .then(result=>sendResponse({ok:true,result})).catch(e=>sendResponse({ok:false,error:e.message}));
  return true;
});
configureInsarangAuto().catch(()=>{});
