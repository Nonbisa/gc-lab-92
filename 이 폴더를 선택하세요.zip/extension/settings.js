const keys=['reminderEnabled'];
const SESSION_CHECK_INTERVAL_MS=10*60*1000;
const $=id=>document.getElementById(id);let dirty=false;
const time=t=>new Date(t).toLocaleString('ko-KR',{timeZone:'Asia/Seoul',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});
let stateSnapshot=null;
function renderSessionState(){
 if(!stateSnapshot)return;
 const a=stateSnapshot.insarangAutoState||{},labels={off:'권한 없음',waiting:'확인 완료',extended:'연장 성공',failed:'연장 실패',expired:'로그인 만료',not_logged_in:'로그인 필요',no_tab:'인사랑 탭 없음',timer_unknown:'남은 시간 인식 불가',unavailable:'연장 버튼 확인 필요',cooldown:'재시도 대기',extending:'연장 확인 중'};
 const parts=[labels[a.status]||'대기 중'];
 if(Number.isFinite(a.remaining))parts.push(Math.ceil(a.remaining/60)+'분 남음');
 if(a.lastSuccess)parts.push('성공 '+time(a.lastSuccess));
 if(Number.isFinite(a.checkedAt)&&a.status!=='off'){
  const seconds=Math.max(0,Math.ceil((SESSION_CHECK_INTERVAL_MS-(Date.now()-a.checkedAt))/1000));
  parts.push('다음 자동확인까지 '+Math.floor(seconds/60)+'분 '+String(seconds%60).padStart(2,'0')+'초');
 }
 $('sessionState').textContent=parts.join(' · ');
}
async function render(){const s=await chrome.storage.local.get(null);stateSnapshot=s;if(!dirty)for(const k of keys)$(k).checked=s[k]!==false;
 renderSessionState();
 const r=s.record;$('recordState').textContent=!r?'기록 버튼 클릭 대기':({pending:'예약 '+time(r.dueAt)+' · '+Math.max(0,Math.ceil((r.dueAt-Date.now())/60000))+'분 남음',notified:'알림 처리됨 · '+time(r.dueAt),cancelled:'알림 취소됨 · 다음 기록 클릭 시 다시 시작'}[r.state]||r.state)+(s.deliveryError?' · '+s.deliveryError:'');
}
for(const k of keys)$(k).onchange=()=>{dirty=true;};
async function send(type,extra={}){const r=await chrome.runtime.sendMessage({type,...extra});if(!r?.ok)throw Error(r?.error||'요청 실패');return r;}
function bind(id,fn){$(id).onclick=async()=>{$(id).disabled=true;try{await fn();await render();}catch(e){$('feedback').textContent=e.message;}finally{$(id).disabled=false;}};}
bind('save',async()=>{await send('LOCAL_SAVE',{values:Object.fromEntries(keys.map(k=>[k,$(k).checked]))});dirty=false;$('feedback').textContent='저장했습니다.';});
bind('extend',async()=>{await send('INSARANG_AUTO_EXTEND_NOW');$('feedback').textContent='연장 결과를 확인하세요.';});
bind('clickGridConfirm',async()=>{const result=await send('LOCAL_CLICK_GRID_CONFIRM');$('feedback').textContent=result.message||'확인 처리 함수를 호출했습니다.';});
bind('test',async()=>{$('feedback').textContent='5초 후 테스트 창을 엽니다.';await send('LOCAL_TEST');});
bind('cancel',()=>send('LOCAL_CANCEL'));
chrome.storage.onChanged.addListener(()=>render().catch(()=>{}));render().catch(console.error);setInterval(renderSessionState,1000);
